import pygame
import os

import tower

pygame.init()

TOWER_IMAGE = pygame.image.load(os.path.join("images", "rapid_test.png"))
BUTTON_IMAGE = pygame.image.load(os.path.join("images", "upgrade_menu.png"))
UPGRADE_BNT_IMAGE = pygame.image.load(os.path.join("images", "upgrade.png"))
SELL_BNT_IMAGE = pygame.image.load(os.path.join("images", "sell.png"))


class UpgradeMenu:
    def __init__(self, x, y):
        # the adjustment of icons
        self.tower = pygame.transform.scale(TOWER_IMAGE, (70, 70))
        self.button = pygame.transform.scale(BUTTON_IMAGE, (150, 150))
        self.upgrade = pygame.transform.scale(UPGRADE_BNT_IMAGE, (50, 30))
        self.sell = pygame.transform.scale(SELL_BNT_IMAGE, (30, 30))
        self.rect = self.tower.get_rect()

        # tower center
        self.rect.center = (x, y)

        # button control
        self.__buttons = [Button(self.upgrade, "upgrade", self.rect.centerx, self.rect.centery - 100), \
                          Button(self.sell, "sell", self.rect.centerx, self.rect.centery + 40), ]

        # (Q2) Add buttons here

    def draw(self, win):
        """
        (Q1) draw menu itself and the buttons
        (This method is call in draw() method in class TowerGroup)
        :return: None
        """
        # (Q2) Draw buttons(three patterns) here

        win.blit(self.button, (self.rect.centerx - 80, self.rect.centery - 80))
        win.blit(self.upgrade, (self.rect.centerx - 30, self.rect.centery - 75))
        win.blit(self.sell, (self.rect.centerx - 20, self.rect.centery + 35))

    def get_buttons(self):
        """
        (Q1) Return the button list.
        (This method is call in get_click() method in class TowerGroup)
        :return: list
        """
        return self.__buttons


class Button:
    def __init__(self, image, name, x, y):
        self.name = name
        # self.buttons = [Button(U)]
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

    def clicked(self, x, y):
        """
        (Q2) Return Whether the button is clicked
        (This method is call in get_click() method in class TowerGroup)
        :param x: mouse x
        :param y: mouse y
        :return: bool
        """
        if self.rect.collidepoint(x,y):
            return True
        else:
            return False

    def response(self):
        """
        (Q2) Return the button name.
        (This method is call in get_click() method in class TowerGroup)
        :return: str
        """
        return self.name




